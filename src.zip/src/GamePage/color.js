

export const gray =  "!bg-[#151617]"
export const graydark = "!bg-[#1F2937]"
export const graymedium = "!bg-gray-500"
export const red = "#BC0319"