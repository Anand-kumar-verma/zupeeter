import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import {
  Box,
  Button,
  Checkbox,
  Container,
  FormControl,
  FormControlLabel,
  IconButton,
  InputAdornment,
  OutlinedInput,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import axios from "axios";
import { useFormik } from "formik";
import React, { useState } from "react";
import toast from "react-hot-toast";
import { NavLink, useNavigate } from "react-router-dom";
import * as uuid from "uuid";
import { zubgback, zubgbackgrad, zubgmid } from "../../../Shared/color";
import iphone from "../../../assets/images/iphone.png";
import email from "../../../assets/images/login.png";
import logo from "../../../assets/images/logo.png";
import password from "../../../assets/images/password (1).png";
import phone from "../../../assets/images/password.png";
import emailauth from "../../../assets/images/safe-mail.png";
import { endpoint } from "../../../services/urls";

function Login() {
  const device_id = uuid.v4();
  const [Nav, setNav] = useState(1);
  const [showPassword, setShowPassword] = React.useState(false);
  const navigate = useNavigate();
  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const initialValue = {
    mob: "",
    email: "",
    pass: "",
    device_id: device_id || uuid.v4(),
  };

  const fk = useFormik({
    initialValues: initialValue,
    onSubmit: () => {
      if (!fk.values.email || !fk.values.pass)
        return toast("Please fill details");
      const reqbody = {
        username: fk.values.email,
        password: fk.values.pass,
      };
      loginFunction(reqbody);
    },
  });

  const loginFunction = async (reqbody) => {
    try {
      const response = await axios.post(endpoint.login, reqbody, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      });

      toast.success(response?.data?.msg);
      console.log(response);
      if (response?.data?.error === "200") {
        localStorage.setItem("logindata", JSON.stringify(response?.data));
        sessionStorage.setItem("isAvailableUser", true);
        get_user_data(response?.data?.UserID);
        navigate("/dashboard");
      }
    } catch (e) {
      toast.error(e?.message);
      console.error(e);
    }
  };

  const get_user_data = async (id) => {
    console.log(id);
    try {
      const response = await axios.get(
        `${endpoint.get_data_by_user_id}?id=${id}`,
        {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        }
      );
      console.log(response, "This is response");

      if (response?.data?.error === "200") {
        localStorage.setItem(
          "aviator_data",
          JSON.stringify(response?.data?.data)
        );
      }
    } catch (e) {
      toast(e?.message);
      console.error(e);
    }
  };

  return (
    <Container sx={style.root}>
      <Box
        sx={{
          width: "100%",
          height: "100vh",
          objectFit: "contain",
          opacity: "0.2",
          position: "fixed",
          top: 0,
          maxWidth: "575px",
          background: zubgbackgrad,
        }}
      ></Box>
      <Box sx={{ position: "absolute", top: "0", left: "0", width: "100%" }}>
        <Box sx={{ width: "100%" }}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Box sx={style.col}>
              <Box component="img" src={logo} alt="logo" sx={style.logo} />
            </Box>
          </Box>
          <Box
            sx={{
              width: "95%",
              marginLeft: "2.5%",
              background: zubgmid,
              borderRadius: "10px",
              mb: "10px",
              mt: "20px",
            }}
          >
            <Box className="register_header" sx={style.registerHeader}>
              <Typography variant="h3">Log in</Typography>
              <Typography variant="h6">
                Please log in with your phone number or email
              </Typography>
              <Typography variant="h6">
                If you forget your password, please contact customer service
              </Typography>
            </Box>
          </Box>
        </Box>
        <Box
          sx={{
            width: "95%",
            background: zubgmid,
            marginLeft: "2.5%",
            borderRadius: "10px",
            mt: "20px",
          }}
        >
          <Box sx={{ width: "100%", borderRadius: "10px" }}>
            <Stack direction="row">
              <Box
                component={NavLink}
                onClick={() => setNav(1)}
                className={Nav === 1 ? "activeNav nav" : "nav"}
              >
                <Box component="img" src={phone} width={40}></Box>
                <Typography variant="h3">LOGIN WITH PHONE</Typography>
              </Box>
              <Box
                component={NavLink}
                onClick={() => setNav(2)}
                className={Nav === 2 ? "activeNav nav" : " nav"}
              >
                <Box component="img" src={email} width={40}></Box>
                <Typography variant="h3">LOGIN WITH EMAIL</Typography>
              </Box>
            </Stack>
          </Box>
        </Box>

        {Nav === 1 && (
          <Box
            component="form"
            sx={{
              width: "95%",
              marginLeft: "2.5%",
              transition: "0.3s",
              padding: " 30px 0px",
            }}
            onSubmit={(e) => {
              e.preventDefault();
              fk.handleSubmit();
            }}
          >
            <Box mt={2}>
              <FormControl fullWidth>
                <Stack direction="row" className="loginlabel">
                  <Box component="img" src={iphone} width={40}></Box>
                  <Typography variant="h3">Phone number</Typography>
                </Stack>
                <TextField
                  id="mob"
                  name="mob"
                  type="mobile"
                  value={fk.values.mob}
                  onChange={fk.handleChange}
                  onKeyDown={(e) => e.key === "Enter" && fk.handleSubmit()}
                  placeholder="Enter phone number"
                  className="loginfields"
                />
              </FormControl>
            </Box>
            <Box mt={3}>
              <FormControl fullWidth>
                <Stack direction="row" className="loginlabel">
                  <Box component="img" src={password} width={40}></Box>
                  <Typography variant="h3" sx={{ marginLeft: "15px" }}>
                    Password
                  </Typography>
                </Stack>
                <OutlinedInput
                  id="pass"
                  name="pass"
                  value={fk.values.pass}
                  onChange={fk.handleChange}
                  placeholder="Enter password"
                  onKeyDown={(e) => e.key === "Enter" && fk.handleSubmit()}
                  className="loginfieldspass"
                  type={showPassword ? "text" : "password"}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {showPassword ? (
                          <VisibilityOff sx={{ color: "white" }} />
                        ) : (
                          <Visibility sx={{ color: "white" }} />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </Box>
            <Box mt={1}>
              <FormControl fullWidth>
                <FormControlLabel
                  required
                  control={<Checkbox sx={{ color: "white" }} />}
                  label="Remember password"
                  sx={{ color: "white" }}
                />
              </FormControl>
            </Box>
            <Stack className="loginbtnbox" mt={2}>
              <Box>
                <Button
                  type="submit"
                  value="Submit"
                  component={NavLink}
                  className="btnLogin"
                  onClick={fk.handleSubmit}
                >
                  Let's go
                </Button>
              </Box>
              <Box mt={2}>
                <Button
                  component={NavLink}
                  className="btnregister"
                  mt={2}
                  to="/register"
                >
                  Register
                </Button>
              </Box>
            </Stack>
          </Box>
        )}
        {Nav === 2 && (
          <Box
            component="form"
            sx={{
              width: "95%",
              marginLeft: "2.5%",
              padding: " 30px 0px",
              transition: "0.3s",
            }}
            onSubmit={(e) => {
              e.preventDefault();
              fk.handleSubmit();
            }}
          >
            <Box mt={2}>
              <FormControl fullWidth>
                <Stack direction="row" className="loginlabel">
                  <Box component="img" src={emailauth} width={40}></Box>
                  <Typography variant="h3" sx={{ marginLeft: "15px" }}>
                    Email
                  </Typography>
                </Stack>
                <TextField
                  id="email"
                  type="email"
                  name="email"
                  placeholder="Enter email"
                  className="loginfields"
                  value={fk.values.email}
                  onChange={fk.handleChange}
                  onKeyDown={(e) => e.key === "Enter" && fk.handleSubmit()}
                />
              </FormControl>
            </Box>
            <Box mt={3}>
              <FormControl fullWidth>
                <Stack direction="row" className="loginlabel">
                  <Box component="img" src={password} width={40}></Box>
                  <Typography variant="h3" sx={{ ml: "15px" }}>
                    Password
                  </Typography>
                </Stack>
                <OutlinedInput
                  placeholder="Enter password"
                  className="loginfieldspass"
                  id="pass"
                  name="pass"
                  value={fk.values.pass}
                  onChange={fk.handleChange}
                  onKeyDown={(e) => e.key === "Enter" && fk.handleSubmit()}
                  type={showPassword ? "text" : "password"}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {showPassword ? (
                          <VisibilityOff sx={{ color: "white" }} />
                        ) : (
                          <Visibility sx={{ color: "white" }} />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </Box>
            <Box mt={1}>
              <FormControl fullWidth>
                <FormControlLabel
                  required
                  control={<Checkbox sx={{ color: "white" }} />}
                  label="remember password"
                  sx={{ color: "white" }}
                />
              </FormControl>
            </Box>
            <Stack className="loginbtnbox" mt={2}>
              <Box>
                <Button
                  component={NavLink}
                  className="btnLogin"
                  onClick={fk.handleSubmit}
                >
                  Let's go
                </Button>
              </Box>
              <Box mt={2}>
                <Button
                  component={NavLink}
                  to="/register"
                  className="btnregister"
                  mt={2}
                >
                  Register
                </Button>
              </Box>
            </Stack>
          </Box>
        )}
      </Box>
    </Container>
  );
}

export default Login;

const style = {
  root: { background: zubgback, position: "relative" },
  col: { width: "33%" },
  img: { width: "50px", height: "50px", padding: "10px" },
  logo: { width: "160px", padding: "5px" },
  formControl: { float: "right", marginRight: "5px", marginTop: "5px" },
  select: { "& > .MuiSelect-select": { width: "50px", padding: "14px 38px" } },
  registerHeader: { "&>h3": { color: "white" }, "&>h6": { color: "white" } },
};
