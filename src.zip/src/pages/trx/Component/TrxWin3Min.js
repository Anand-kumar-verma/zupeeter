import React from 'react'

function TrxWin3Min() {
  return (
    <div>TrxWin3Min</div>
  )
}

export default TrxWin3Min