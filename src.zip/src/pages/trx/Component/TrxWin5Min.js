import React from 'react'

function TrxWin5Min() {
  return (
    <div>TrxWin5Min</div>
  )
}

export default TrxWin5Min